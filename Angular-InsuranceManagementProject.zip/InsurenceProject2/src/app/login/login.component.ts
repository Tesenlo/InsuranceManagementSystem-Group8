import { Component, OnInit } from '@angular/core';
import { AuthenticationStatus } from '../AuthenticationStatus.model';
import { LoginService } from '../login.service';
import { ActivatedRoute,Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { UsernameService } from '../username.service';
import { Login } from '../login';
import { User } from '../user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user : User = new User()
 
  constructor(
    private loginService: LoginService,
    private router: Router,
    private route: ActivatedRoute,
    private usernameService:UsernameService
  ) { }

  ngOnInit(): void { }
  onSubmit() {
    this.loginService.loginUser(this.user).subscribe(data=>{
      if(data===null){
        alert("Login Failed!")
        this.router.navigate(['/home'])
      }else{     
        this.user = data;
        this.usernameService.setUsername(data.userName);
        console.info(data.userName);
        console.info(this.usernameService.getUsername)
        alert("Login Successful!")
        this.router.navigate(['/user'])
      }

    })
  }


}
