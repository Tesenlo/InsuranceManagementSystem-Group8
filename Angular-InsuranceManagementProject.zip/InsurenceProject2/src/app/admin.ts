export class admin {

       public username:string;
       public password:string;  

}
