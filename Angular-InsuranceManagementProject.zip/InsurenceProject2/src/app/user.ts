export class User {
    
      userid:string;
      userName:string;
      password:string;
      email:string;
      mobile:string
    
}
