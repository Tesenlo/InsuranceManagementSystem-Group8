import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { AuthenticationStatus } from "./AuthenticationStatus.model"; 
import { admin } from "./admin";


@Injectable({
    providedIn: 'root',
})

export class AdminServiceService {

    constructor(private httpClient: HttpClient) {}

    validateUrl="http://localhost:9091/api/v1/validateAdmin";

    validateAdmin(adminObj: admin):Observable<admin>{
        return this.httpClient.post<admin>(`${this.validateUrl}`,adminObj);
    }


    
  }