import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { AuthenticationStatus } from "./AuthenticationStatus.model"; 
import { User } from "./user";


@Injectable({
  providedIn: 'root'
})
export class LoginService {
  constructor(private httpClient: HttpClient) {}

  private baseUrl="http://localhost:9091/api/v1/userLogin";
  loginUser(user: User):Observable<User>{
    return this.httpClient.post<User>(`${this.baseUrl}`,user)
  }
}