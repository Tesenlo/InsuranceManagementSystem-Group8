import { Component, OnInit } from '@angular/core';
import { updateModel } from '../updateModel';
import { UpdateService } from '../update.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-updateprofice',
  templateUrl: './updateprofice.component.html',
  styleUrls: ['./updateprofice.component.css']
})
export class UpdateproficeComponent implements OnInit {

  updateModel = new updateModel('', '', '', '', '');
  message: string = '';

  constructor(private updateService: UpdateService, private route: Router) { }

  ngOnInit(): void {
  }

  onSubmit() {
    this.updateService.enroll(this.updateModel).subscribe(
      data => {
        this.message = 'Updated Successfully';
        console.log('success', data);

        // Clear the message after 3 seconds
        setTimeout(() => {
          this.message = '';
        }, 3000);
         // Reset the form fields
      this.updateModel = new updateModel('', '', '', '', '');
      this.route.navigate(['/user']);
      },
      error => {
        this.message = 'An error occurred';
        console.error('error', error);

        // Clear the message after 3 seconds
        setTimeout(() => {
          this.message = '';
        }, 3000);
      }
    );
  }
}