import { Component, OnInit } from '@angular/core';
import { AuthenticationStatus } from '../AuthenticationStatus.model';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { admin } from '../admin';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  
  adminObj : admin = new admin; 
  
 
  constructor(
    private loginService: AdminServiceService,
    private router: Router,
  ) { }

  ngOnInit(): void { 

  }

  onSubmit() {
    this.loginService.validateAdmin(this.adminObj).subscribe(data=>{
      if(data==null){
        console.info("Entered to submit function")
        alert("Login Failed!")
        this.router.navigateByUrl("home")
      }else{
        alert("Login Successful!")
        this.router.navigateByUrl("adminhome")
      }
    })
  }


}
