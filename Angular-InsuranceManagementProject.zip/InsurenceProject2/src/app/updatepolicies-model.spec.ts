import { UpdatepoliciesModel } from './updatepolicies-model';

describe('UpdatepoliciesModel', () => {
  it('should create an instance', () => {
    expect(new UpdatepoliciesModel()).toBeTruthy();
  });
});
