import { Adminstrator } from './adminstrator';

describe('Adminstrator', () => {
  it('should create an instance', () => {
    expect(new Adminstrator()).toBeTruthy();
  });
});
