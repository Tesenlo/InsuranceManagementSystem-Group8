import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { policies } from '../policies';
import { PolicyService } from '../policy.service';
import { UpdatepolicyService } from '../updatepolicy.service';
import { Category } from '../category';

@Component({
  selector: 'app-updatepolicies',
  templateUrl: './updatepolicies.component.html',
  styleUrls: ['./updatepolicies.component.css']
})
export class UpdatepoliciesComponent implements OnInit {

  categories:Category[];  //category array

  policies:any={}         //policy variable

  policy_id!:number;

  constructor(private activeRouter:ActivatedRoute,
              private _updatepolicyService:UpdatepolicyService,
              private getService:PolicyService, 
              private router:Router) { }


  ngOnInit(): void {
    this.policy_id = this.activeRouter.snapshot.params[`policyId`]; //get the id from the route

    this._updatepolicyService.getPolicy(this.policy_id).subscribe(data => this.policies=data); //get the policy with policy id

    this.getService.getCategory().subscribe(data=>{ //get all categories and populate in dropdown list
      this.categories=data;
      console.info(this.categories)
    })  
  }
  

  onSubmit(){
    alert("Updated SuccessFully");
    this._updatepolicyService.enroll(this.policies).subscribe(data => console.log('succsess', data),error => console.error('error', error))
    
    this.router.navigate(['/adminhome'])
  }

  setCategory(e){   //change in drop will fire this method and set the policy category
    this.policies.category=e.target.value;
}


}
