import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  redirectToExternalPage() {
    window.open('https://www.businessworld.in/article/HDFC-Life-s-Assets-Under-Management-Cross-Rs-2-5-Lakh-Cr-/14-06-2023-480511/', '_blank'); 
  }
  redirectToExternal() {
    window.open('https://economictimes.indiatimes.com/wealth/insure/life-insurance/latest-life-insurance-claim-settlement-ratio-of-insurance-companies-in-india/articleshow/97366610.cms', '_blank'); 
  }
  redirectPage() {
    window.open('https://www.businesstoday.in/markets/top-story/story/zerodha-nithin-kamath-t1-settlement-cycle-india-367560-2023-01-25', '_blank'); 
  }

}