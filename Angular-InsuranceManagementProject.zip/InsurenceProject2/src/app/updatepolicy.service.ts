import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { policies } from './policies';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UpdatepolicyService {

  _url = 'http://localhost:9091/api/v1/policy'; 


  constructor(private _http: HttpClient) {}


    enroll(update:any){      //update policy
      return this._http.put<any>(this._url, update)
   }

   getPolicy(policy_id:number){ //get policy
    return this._http.get<any>(`${this._url}/${policy_id}`)

   }

}
