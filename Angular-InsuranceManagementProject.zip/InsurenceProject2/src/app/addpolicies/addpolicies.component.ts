import { Component, OnInit } from '@angular/core';
import { policies } from '../policies';
import { PolicyService } from '../policy.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Category } from '../category';

@Component({
  selector: 'app-addpolicies',
  templateUrl: './addpolicies.component.html',
  styleUrls: ['./addpolicies.component.css']
})
export class AddpoliciesComponent implements OnInit {

  categories:Category[];
  addpoliciesModel = new policies('', '', '', '')
  constructor(private _addpolicyService:PolicyService,private http:HttpClient,private router:Router) { 

    this.addpoliciesModel = new policies('', '', '', '');
  }

  
  _url = 'http://localhost:9091/api/v1/categories';

  
 

  

  ngOnInit(): void {

    this._addpolicyService.getCategory().subscribe(data=>{
      this.categories=data;
      console.info(this.categories)
    })  

  }


  onSubmit(){
    alert("Added Successful");
    this._addpolicyService.addpolicy(this.addpoliciesModel)
    .subscribe(
      data => console.log('success',data),
      error => console.error('error',error)
    )
    this.router.navigateByUrl('viewpolicies')
  }

  setCategory(e){
      this.addpoliciesModel.category=e.target.value;
  }
}
