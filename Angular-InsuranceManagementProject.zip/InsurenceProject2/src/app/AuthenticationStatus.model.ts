export class AuthenticationStatus {
    userName!: string;
    password!: string;
    authenticated!: boolean
    constructor() {}

}