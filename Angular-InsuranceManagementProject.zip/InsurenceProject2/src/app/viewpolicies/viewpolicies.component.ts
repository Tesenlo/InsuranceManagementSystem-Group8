import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DeleteService } from '../delete.service';
import { policies } from '../policies';
import { UpdatepolicyService } from '../updatepolicy.service';


@Component({
  selector: 'app-viewpolicies',
  templateUrl: './viewpolicies.component.html',
  styleUrls: ['./viewpolicies.component.css']
})
export class ViewpoliciesComponent implements OnInit {

  books : any;
 
  policies = new policies('','','','');

  constructor(private http:HttpClient,
              private router:Router,
              private deleteservice: DeleteService,
              private service:UpdatepolicyService) { }
 
 
 
  _url = 'http://localhost:9091/api/v1/policies'; //for retrieving policies url
  
  ngOnInit() {
   
    let responce =  this.http.get(this._url);
    responce.subscribe((data)=>this.books=data);
 
  }

  updatePolicy(policyId: number){
    console.log(policyId);
    this.router.navigate(["updatepolicy", policyId]);
  }



  deletePolicy(book:any){
    this.deleteservice.deletePolicy(book.policyId).subscribe(data=>{
     this.router.navigateByUrl('viewpolicies');
    })
    
    
  }


 

}
