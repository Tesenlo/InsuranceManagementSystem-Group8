package com.insurance.management.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.management.repository.AdminRepository;
import com.insurance.management.model.Admin;
import com.insurance.management.model.AuthenticationStatus;
@Service
public class AdminService {

	@Autowired
	AdminRepository adminRepository;
	public Admin validateAdmin(String username, String password) {
		return adminRepository.validateAdmin(username, password);
	}
	
}