package com.insurance.management.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.insurance.management.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, String> {
	//for login validation
		String query = "select u from User u where u.userName=?1 and u.password=?2";
		@Query(query)
		public User userLogin(String username, String password);

}
