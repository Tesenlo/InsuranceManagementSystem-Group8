package com.insurance.management;

import static org.assertj.core.api.Assertions.assertThat;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.insurance.management.model.Approvals;
import com.insurance.management.model.Category;
import com.insurance.management.model.Disapproved;
import com.insurance.management.model.Policies;
import com.insurance.management.model.Queries;
import com.insurance.management.model.User;
import com.insurance.management.repository.ApprovalsRepository;
import com.insurance.management.repository.ApprovedRepository;
import com.insurance.management.repository.CategoryRepository;
import com.insurance.management.repository.DisapprovedRepository;
import com.insurance.management.repository.PoliciesRepository;
import com.insurance.management.repository.QueriesRepository;
import com.insurance.management.repository.UserRepository;

@SpringBootTest
class ManagementApplicationTests {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private PoliciesRepository policyRepo;

//	
//	@Test
//	public void userLogin() {
//		User user = new User();
//		user.setUserName("Tesenlo");
//		user.setEmail("tesenlo@yahoo.com");
//		user.setMobile(1010101010);
//		user.setPassword("tes123");
//		User actualUser = userRepository.save(user);												//saved user or actual
//		
//		User expectedUser = userRepository.userLogin("Tesenlo", "tes123"); //user logging in	or expected	
//		System.out.println(expectedUser.getEmail());
//		System.out.println(actualUser.getEmail());
//		assertEquals(actualUser.getEmail(), expectedUser.getEmail() );
//	}
	
	
	@Test
	public void updatePolicy() {
		Policies policy = new Policies();
		policy.setPolicyName("SBI");
		policy.setCategory("Health");
		policy.setAmount(1000.00);
		policy.setTenureInYears(2);
		policyRepo.save(policy);
		assertNotNull(policyRepo.findById(27).get());
		
		
	}


	

	

	

}
